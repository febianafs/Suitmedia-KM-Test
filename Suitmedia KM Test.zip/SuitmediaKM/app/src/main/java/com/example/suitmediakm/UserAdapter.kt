package com.example.suitmediakm

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class UserAdapter(private val users: List<User>, private val onItemClick: (User) -> Unit) :
    RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = users[position]
        holder.bind(user)

        // Handle item click
        holder.itemView.setOnClickListener {
            onItemClick(user)
        }
    }

    override fun getItemCount(): Int = users.size

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvUsername: TextView = itemView.findViewById(R.id.tv_username)
        private val tvEmail: TextView = itemView.findViewById(R.id.tv_email)
        private val imgAvatar: ImageView = itemView.findViewById(R.id.img_avatar)

        fun bind(user: User) {
            tvUsername.text = "${user.first_name} ${user.last_name}"
            tvEmail.text = user.email
            Glide.with(itemView.context)
                .load(user.avatar)
                .circleCrop()  // Membuat gambar menjadi bulat
                .into(imgAvatar)
        }
    }
}
