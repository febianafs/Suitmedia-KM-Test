package com.example.suitmediakm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var etName: EditText
    private lateinit var etSentence: EditText
    private lateinit var btnCheck: Button
    private lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etName = findViewById(R.id.et_name)
        etSentence = findViewById(R.id.et_sentence)
        btnCheck = findViewById(R.id.btn_check)
        btnNext = findViewById(R.id.btn_next)

        // Cek apakah kalimat adalah palindrom
        btnCheck.setOnClickListener {
            val sentence = etSentence.text.toString().replace(" ", "").lowercase()
            if (isPalindrome(sentence)) {
                showDialog("Palindrome")
            } else {
                showDialog("Not Palindrome")
            }
        }

        // Pindah ke layar kedua dengan mengirimkan data
        btnNext.setOnClickListener {
            val name = etName.text.toString()

            if (name.isEmpty()) {
                showDialog("Name cannot be empty")  // Tampilkan dialog jika nama kosong
            } else {
                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("name", name)  // Kirim nama yang dimasukkan ke SecondActivity
                startActivity(intent)
            }
        }
    }

    // Fungsi untuk mengecek apakah string adalah palindrome
    private fun isPalindrome(text: String): Boolean {
        return text == text.reversed()
    }

    // Fungsi untuk menampilkan dialog
    private fun showDialog(message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        builder.create().show()
    }
}