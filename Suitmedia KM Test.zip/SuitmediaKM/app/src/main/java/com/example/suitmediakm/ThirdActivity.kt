package com.example.suitmediakm

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ThirdActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var userAdapter: UserAdapter
    private val users = mutableListOf<User>()
    private var currentPage = 1
    private var totalPages = 1
    private var isLoading = false

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        recyclerView = findViewById(R.id.recycler_view)
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout)

        // Setup Toolbar as ActionBar
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Third Screen"

        // Set the toolbar title text color to black programmatically
        toolbar.setTitleTextColor(resources.getColor(android.R.color.black, theme))

        // Mengubah warna back button menjadi hitam
        toolbar.navigationIcon?.setTint(resources.getColor(android.R.color.black, theme))

        userAdapter = UserAdapter(users) { user ->
            val resultIntent = Intent().apply {
                putExtra("selectedUserName", "${user.first_name} ${user.last_name}")
            }
            setResult(RESULT_OK, resultIntent)
            finish()
        }


        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = userAdapter

        swipeRefreshLayout.setOnRefreshListener {
            refreshData()
        }

        loadData(currentPage)

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (!recyclerView.canScrollVertically(1) && !isLoading && currentPage < totalPages) {
                    loadData(++currentPage)
                }
            }
        })
    }

    // Handle the back button in the toolbar
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()  // Handle back button
        return true
    }

    private fun loadData(page: Int) {
        isLoading = true
        RetrofitClient.instance.getUsers(page, 10).enqueue(object : Callback<UserResponse> {
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                if (response.isSuccessful) {
                    response.body()?.let { userResponse ->
                        users.addAll(userResponse.data)
                        totalPages = userResponse.total_pages
                        userAdapter.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(this@ThirdActivity, "Failed to load data", Toast.LENGTH_SHORT).show()
                }
                isLoading = false
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                isLoading = false
                swipeRefreshLayout.isRefreshing = false
                Toast.makeText(this@ThirdActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun refreshData() {
        users.clear()
        currentPage = 1
        loadData(currentPage)
    }
}