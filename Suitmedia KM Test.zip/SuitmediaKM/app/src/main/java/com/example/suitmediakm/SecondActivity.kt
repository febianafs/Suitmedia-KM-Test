package com.example.suitmediakm

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


    class SecondActivity : AppCompatActivity() {

        private lateinit var tvShowName: TextView
        private lateinit var tvSelectedUser: TextView
        private lateinit var btnChooseUser: Button

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_second)

            // Setup Toolbar as ActionBar
            val toolbar: Toolbar = findViewById(R.id.toolbar)
            setSupportActionBar(toolbar)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.title = "Second Screen"

            // Bind views
            tvShowName = findViewById(R.id.tv_show_name)
            tvSelectedUser = findViewById(R.id.tv_selected_user)
            btnChooseUser = findViewById(R.id.btn_choose_user)

            // Get the data from the First Screen (MainActivity)
            val name = intent.getStringExtra("name")
            tvShowName.text = name

            // Set action for the button to go to Third Screen
            btnChooseUser.setOnClickListener {
                val thirdScreenIntent = Intent(this, ThirdActivity::class.java)
                startActivityForResult(thirdScreenIntent, 1)
            }
        }

        // Handle the back button in the toolbar
        override fun onSupportNavigateUp(): Boolean {
            onBackPressed()  // Handle back button
            return true
        }

        // Handle the result from Third Screen
        override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
            super.onActivityResult(requestCode, resultCode, data)
            if (requestCode == 1 && resultCode == RESULT_OK) {
                val selectedUserName = data?.getStringExtra("selectedUserName")
                tvSelectedUser.text = selectedUserName
            }
        }
    }